/**
 * Chenhanlei��all right reseverd.
 * 2021.4.26
 *�汾��1.0 
 */

int intosystem();
int checkcode(char a[8],char b[8]);
void reader();
void returnbook();
int Recommendbook();
void borrowbook();
void turnzero(char *p,int a);
void intocata(int a,int b,char p[20],char pp[55]);
void Recommendbookinner();
void showallhistory();
void showallbook();
int StrCount(FILE *file,char *str);
int stringnuminfilee(char nametemp[20]);
int administrater();
void buying_asking();
void book_information();
void addbook();
void deletbook();
void renewbook();
void reader_control();
void showallreader();
void addreader();
void deletreader();
void renewreader();
void showallreaderhistory();
 
